



document.addEventListener('DOMContentLoaded', function () {
    initTyped();
});


function initTyped() {
    typed = new Typed('#element', {
        strings: ['Web Developer', 'Android Developer', 'Programmer' , 'Gamer'],
        typeSpeed: 60,
        loop: true 
    });
}

function stopTyped() {
    typed.destroy();
}

document.addEventListener('DOMContentLoaded', function () {
    var toggleIcons = document.getElementById('toggleIcons');
    var iconContainer = document.getElementById('iconContainer');

    toggleIcons.addEventListener('click', function () {
        iconContainer.classList.toggle('show');
    });
});




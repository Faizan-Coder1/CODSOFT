document.addEventListener('DOMContentLoaded', function () {
    const taskInput = document.getElementById('taskInput');
    const taskDescription = document.getElementById('taskDescription');
    const addTaskButton = document.getElementById('addTask');
    const taskList = document.getElementById('taskList');

    addTaskButton.addEventListener('click', addTask);

    const savedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
    savedTasks.forEach(task => {
        createTaskElement(task);
    });

    function addTask() {
        const taskText = taskInput.value.trim();
        const taskDesc = taskDescription.value.trim();
        if (taskText === '') return;

        const task = {
            text: taskText,
            description: taskDesc,
            id: Date.now(),
        };

        createTaskElement(task);
        savedTasks.push(task);

        localStorage.setItem('tasks', JSON.stringify(savedTasks));

        taskInput.value = '';
        taskDescription.value = '';
    }

    function createTaskElement(task) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${task.text}</td>
            <td class="description">${task.description}</td>
            <td>
                <button class="deleteTask" data-id="${task.id}">Delete</button>
                <button class="editTask" data-id="${task.id}">Edit</button>
            </td>
        `;
        taskList.appendChild(tr);
    }

    taskList.addEventListener('click', function (event) {
        const target = event.target;
        if (target.classList.contains('deleteTask')) {
            const taskId = target.getAttribute('data-id');
            const taskIndex = savedTasks.findIndex(item => item.id === parseInt(taskId));
            savedTasks.splice(taskIndex, 1);
            localStorage.setItem('tasks', JSON.stringify(savedTasks));
            target.parentElement.parentElement.remove();
        }

        if (target.classList.contains('editTask')) {
            const taskId = target.getAttribute('data-id');
            const task = savedTasks.find(item => item.id === parseInt(taskId));
            const editText = prompt('Edit task:', task.text);
            const editDesc = prompt('Edit description:', task.description);
            if (editText !== null && editText.trim() !== '') {
                task.text = editText;
                task.description = editDesc;
                const tr = target.parentElement.parentElement;
                tr.innerHTML = `
                    <td>${editText}</td>
                    <td class="description">${editDesc}</td>
                    <td>
                        <button class="deleteTask" data-id="${task.id}">Delete</button>
                        <button class="editTask" data-id="${task.id}">Edit</button>
                    </td>
                `;
                localStorage.setItem('tasks', JSON.stringify(savedTasks));
            }
        }
    });

});
package com.example.quotesapp;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity{

    FloatingActionButton share_btn, favourite_btn;

    Button favourite_quotes;

    private List<QuoteResponse> quotes;
    private int currentQuoteIndex = 0;
    RequestManager manager;
    ProgressDialog dialog;

    private QuoteDbHelper dbHelper;
    private SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new QuoteDbHelper(this);
        db = dbHelper.getWritableDatabase();

        manager = new RequestManager(this);
        manager.GetAllQuotes(listener);

        dialog = new ProgressDialog(this);
        dialog.setTitle("Loading...");
        dialog.show();

        share_btn = findViewById(R.id.share_btn);
        favourite_btn = findViewById(R.id.favourite_btn);
        favourite_quotes = findViewById(R.id.favourite_quotes);

        findViewById(R.id.previousButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPreviousQuote();
            }
        });

        findViewById(R.id.nextButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNextQuote();
            }
        });

        share_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareQuote();
            }
        });

        favourite_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveFavoriteQuote();
            }
        });

        favourite_quotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FavouriteQuotes.class);
                startActivity(intent);
            }
        });
    }

    private void shareQuote() {
        if (quotes != null && quotes.size() > 0) {
            QuoteResponse currentQuote = quotes.get(currentQuoteIndex);
            String textToShare = currentQuote.getText() + "\n\n- " + currentQuote.getAuthor();

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, textToShare);

            Intent chooser = Intent.createChooser(shareIntent, "Share this quote");
            if (shareIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(chooser);
            } else {
                Toast.makeText(this, "No app found to handle this action", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void setRandomQuote() {
        if (quotes != null && !quotes.isEmpty()) {
            int randomIndex = new Random().nextInt(quotes.size());
            QuoteResponse randomQuote = quotes.get(randomIndex);
            TextView quoteText = findViewById(R.id.quoteText);
            TextView quoteAuthor = findViewById(R.id.quoteAuthor);
            quoteText.setText(randomQuote.getText());
            quoteAuthor.setText(randomQuote.getAuthor());
        }
    }

    public void setQuote() {
        TextView quoteText = findViewById(R.id.quoteText);
        TextView quoteAuthor = findViewById(R.id.quoteAuthor);

        if (quotes != null && quotes.size() > 0) {
            QuoteResponse currentQuote = quotes.get(currentQuoteIndex);
            quoteText.setText(currentQuote.getText());
            quoteAuthor.setText(currentQuote.getAuthor());
        }
    }

    private void showNextQuote() {
        if (quotes != null && quotes.size() > 0) {
            currentQuoteIndex = (currentQuoteIndex + 1) % quotes.size();
            setQuote();
        }
    }

    private void showPreviousQuote() {
        if (quotes != null && quotes.size() > 0) {
            currentQuoteIndex = (currentQuoteIndex - 1 + quotes.size()) % quotes.size();
            setQuote();
        }
    }

    private final QuoteResponseListener listener = new QuoteResponseListener() {
        @Override
        public void didFetch(List<QuoteResponse> responses, String message) {
            quotes = responses;
            dialog.dismiss();
            setRandomQuote();
        }

        @Override
        public void didError(String message) {
            Toast.makeText(MainActivity.this, "message", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        }
    };


    private void saveFavoriteQuote() {
        if (quotes != null && quotes.size() > 0) {
            QuoteResponse currentQuote = quotes.get(currentQuoteIndex);

            ContentValues values = new ContentValues();
            values.put(QuoteContract.QuoteEntry.COLUMN_NAME_TEXT, currentQuote.getText());
            values.put(QuoteContract.QuoteEntry.COLUMN_NAME_AUTHOR, currentQuote.getAuthor());

            long newRowId = db.insert(QuoteContract.QuoteEntry.TABLE_NAME, null, values);

            if (newRowId != -1) {
                Toast.makeText(this, "Quote saved to favorites", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error saving quote", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }

}
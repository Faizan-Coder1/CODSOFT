package com.example.quotesapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class QuoteDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Quotes.db";
    private static final int DATABASE_VERSION = 1;

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + QuoteContract.QuoteEntry.TABLE_NAME + " (" +
                    QuoteContract.QuoteEntry._ID + " INTEGER PRIMARY KEY," +
                    QuoteContract.QuoteEntry.COLUMN_NAME_TEXT + " TEXT," +
                    QuoteContract.QuoteEntry.COLUMN_NAME_AUTHOR + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + QuoteContract.QuoteEntry.TABLE_NAME;

    public QuoteDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Inside QuoteDbHelper.java
    public List<QuoteResponse> getAllFavoriteQuotes() {
        List<QuoteResponse> quotes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                QuoteContract.QuoteEntry._ID,
                QuoteContract.QuoteEntry.COLUMN_NAME_TEXT,
                QuoteContract.QuoteEntry.COLUMN_NAME_AUTHOR
        };

        Cursor cursor = db.query(
                QuoteContract.QuoteEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            int textColumnIndex = cursor.getColumnIndex(QuoteContract.QuoteEntry.COLUMN_NAME_TEXT);
            int authorColumnIndex = cursor.getColumnIndex(QuoteContract.QuoteEntry.COLUMN_NAME_AUTHOR);

            String text = cursor.getString(textColumnIndex);
            String author = cursor.getString(authorColumnIndex);

            QuoteResponse quote = new QuoteResponse(text, author);
            quotes.add(quote);
        }

        cursor.close();
        return quotes;
    }
    public void deleteQuote(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = QuoteContract.QuoteEntry._ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };
        db.delete(QuoteContract.QuoteEntry.TABLE_NAME, selection, selectionArgs);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}

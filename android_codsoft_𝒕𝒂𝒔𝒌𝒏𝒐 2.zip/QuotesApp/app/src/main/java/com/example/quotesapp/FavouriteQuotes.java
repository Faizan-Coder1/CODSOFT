package com.example.quotesapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

public class FavouriteQuotes extends AppCompatActivity{

    RecyclerView recycler_view;

    private QuoteDbHelper dbHelper;
    private SQLiteDatabase db;
    QuoteRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite_quotes);

        recycler_view = findViewById(R.id.recycler_view);

        dbHelper = new QuoteDbHelper(this);

        showFavoriteQuotes();
    }


    private void showFavoriteQuotes() {
        List<QuoteResponse> favoriteQuotes = dbHelper.getAllFavoriteQuotes();
        showData(favoriteQuotes);
    }
    private void showData(List<QuoteResponse> responses) {
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL));
        adapter = new QuoteRecyclerAdapter(FavouriteQuotes.this, responses);
        recycler_view.setAdapter(adapter);
    }
    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
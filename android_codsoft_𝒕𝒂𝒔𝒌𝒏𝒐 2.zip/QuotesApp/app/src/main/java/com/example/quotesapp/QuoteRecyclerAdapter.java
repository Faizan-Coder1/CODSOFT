package com.example.quotesapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class QuoteRecyclerAdapter extends RecyclerView.Adapter<QuoteViewHolder>{

    Context context;
    List<QuoteResponse> list;

    QuoteDbHelper dbHelper;

    public QuoteRecyclerAdapter(Context context, List<QuoteResponse> list) {
        this.context = context;
        this.list = list;

        dbHelper = new QuoteDbHelper(context);
    }

    @NonNull
    @Override
    public QuoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new QuoteViewHolder(LayoutInflater.from(context).inflate(R.layout.list_quote, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull QuoteViewHolder holder, int position) {
        holder.quote.setText(list.get(position).getText());
        holder.author.setText(list.get(position).getAuthor());

        holder.shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    QuoteResponse currentQuote = list.get(adapterPosition);
                    String textToShare = currentQuote.getText() + "\n\n- " + currentQuote.getAuthor();

                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_TEXT, textToShare);

                    Intent chooser = Intent.createChooser(shareIntent, "Share this quote");
                    context.startActivity(chooser);
                }
            }
        });

        holder.favouriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    dbHelper.deleteQuote(adapterPosition);
                    list.remove(adapterPosition);
                    notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

class QuoteViewHolder extends RecyclerView.ViewHolder {

    TextView quote, author;
    ImageButton favouriteButton, shareButton;
    public QuoteViewHolder(@NonNull View itemView) {
        super(itemView);
        quote = itemView.findViewById(R.id.textView_quote);
        author = itemView.findViewById(R.id.textView_author);
        favouriteButton = itemView.findViewById(R.id.favourite_btn);
        shareButton = itemView.findViewById(R.id.share_btn);
    }
}

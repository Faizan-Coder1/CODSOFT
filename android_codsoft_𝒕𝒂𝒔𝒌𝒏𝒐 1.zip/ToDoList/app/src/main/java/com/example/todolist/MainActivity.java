package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SearchView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {
    List<Task> taskList = new ArrayList<>();
    RecyclerView recyclerView;
    TaskAdapter taskAdapter;
    TaskDatabaseHelper taskDatabasehelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);

        taskDatabasehelper = new TaskDatabaseHelper(MainActivity.this);
        recyclerView = findViewById(R.id.recyclerview);
        taskAdapter = new TaskAdapter(taskList, MainActivity.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(taskAdapter);
        taskList = taskDatabasehelper.getAllTasks();
        SearchView searchView = findViewById(R.id.searchView);

        searchView.setOnQueryTextListener(this);

        taskAdapter = new TaskAdapter(taskList, MainActivity.this);
        recyclerView.setAdapter(taskAdapter);

        MaterialCardView add = findViewById(R.id.addBtn);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddTask.class);
                startActivity(intent);
            }
        });

    }

    public static void setWindowFlag(Activity activity, final int bits, boolean on) {

        Window win = activity.getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }

    @Override
    public boolean onQueryTextSubmit(String query)
    {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText)
    {
        List<Task> filteredItems = filter(taskList, newText);
        taskAdapter.setTaskList(filteredItems);
        return true;
    }
    private List<Task> filter(List<Task> items, String query)
    {
        query = query.toLowerCase().trim();

        final List<Task> filteredItems = new ArrayList<>();
        for (Task list : items)
        {
            final String title = list.getTitle().toLowerCase();
            final String description = list.getDescription().toLowerCase();

            if (title.contains(query)|| description.contains(query))
            {
                filteredItems.add(list);
            }
        }

        return filteredItems;
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the RecyclerView when the activity resumes to reflect any changes in the data.
        List<Task> list = taskDatabasehelper.getAllTasks();
        taskAdapter.setTaskList(list);
        taskAdapter.notifyDataSetChanged();

         // Sort tasks by due date and status
        taskAdapter.sortTasksByDueDateAndStatus();

    }


}
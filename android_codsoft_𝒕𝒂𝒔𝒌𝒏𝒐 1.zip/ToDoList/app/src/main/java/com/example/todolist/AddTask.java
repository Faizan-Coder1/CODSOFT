package com.example.todolist;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Locale;

public class AddTask extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText title, desc, dueDateEditText;
    Spinner prioritySpinner;
    TaskDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        title = findViewById(R.id.title);
        desc = findViewById(R.id.desc);

        dueDateEditText = findViewById(R.id.dueDateEditText);
        dueDateEditText.setOnClickListener(v -> openDatePicker());
        dbHelper = new TaskDatabaseHelper(this);
        prioritySpinner = findViewById(R.id.prioritySpinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.priority_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        prioritySpinner.setAdapter(adapter);

        prioritySpinner.setOnItemSelectedListener(this);
        findViewById(R.id.saveTask).setOnClickListener(v -> addTask());
    }


    public void openDatePicker() {
        // Create a Calendar instance to get the current date
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Create a DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (DatePickerDialog.OnDateSetListener) (datePicker, year1, month1, day1) -> {
            // Month returned by DatePicker is 0-based, so add 1 to get the correct month
            month1 = month1 + 1;

            // Format the date and set it to the EditText
            String formattedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year1, month1, day1);
            dueDateEditText.setText(formattedDate);
        }, year, month, day);

        // Show the DatePickerDialog
        datePickerDialog.show();
    }

    private void addTask() {
        String taskTitle = title.getText().toString().trim();
        String taskDescription = desc.getText().toString().trim();
        int priority = prioritySpinner.getSelectedItemPosition();
        String dueDate = dueDateEditText.getText().toString();

        if (!taskTitle.isEmpty() && !taskDescription.isEmpty()) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(TaskDatabaseHelper.COLUMN_TITLE, taskTitle);
            values.put(TaskDatabaseHelper.COLUMN_DESCRIPTION, taskDescription);
            values.put(TaskDatabaseHelper.COLUMN_PRIORITY, priority); // Add priority to ContentValues
            values.put(TaskDatabaseHelper.COLUMN_DUE_DATE, dueDate); // Add due date to ContentValues
            values.put(TaskDatabaseHelper.COLUMN_COMPLETED, 0); // Add completion status to ContentValues
            db.insert(TaskDatabaseHelper.TABLE_TASKS, null, values);
            db.close();

            // Show a toast message when the task is saved successfully
            Toast.makeText(this, "Task saved successfully", Toast.LENGTH_SHORT).show();
            title.setText("");
            desc.setText("");

            // Optionally, you can navigate back to the main activity or perform other actions.
        } else {
            Toast.makeText(this, "Please fill in both title and description", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        String selectedItem = parent.getItemAtPosition(position).toString();
        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
        ((TextView) parent.getChildAt(0)).setTextSize(15);


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

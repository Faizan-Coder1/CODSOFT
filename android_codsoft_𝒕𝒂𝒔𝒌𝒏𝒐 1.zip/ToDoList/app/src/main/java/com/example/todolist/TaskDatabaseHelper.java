package com.example.todolist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class TaskDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tasks.db";
    private static final int DATABASE_VERSION = 2;

    // Define the table and column names
    public static final String TABLE_TASKS = "tasks";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_PRIORITY = "priority";
    public static final String COLUMN_DUE_DATE = "due_date";
    public static final String COLUMN_COMPLETED = "completed";

    // Create table SQL query
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_TASKS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TITLE + " TEXT, " +
                    COLUMN_DESCRIPTION + " TEXT, " +
                    COLUMN_PRIORITY + " INTEGER, " +
                    COLUMN_DUE_DATE + " TEXT, " +
                    COLUMN_COMPLETED + " INTEGER);";

    public TaskDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    public List<Task> getAllTasks() {
        List<Task> taskList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID, COLUMN_TITLE, COLUMN_DESCRIPTION, COLUMN_PRIORITY, COLUMN_DUE_DATE, COLUMN_COMPLETED};


        Cursor cursor = db.query(TABLE_TASKS, columns, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndex(COLUMN_ID));
                String title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE));
                String description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION));
                int priority = Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_PRIORITY)));
                String dueDate = cursor.getString(cursor.getColumnIndex(COLUMN_DUE_DATE));
                int completionStatus = Integer.valueOf(cursor.getString(cursor.getColumnIndex(COLUMN_COMPLETED)));

                Task task = new Task(id, title, description, priority, dueDate, completionStatus);
                taskList.add(task);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return taskList;
    }

    public void deleteTask(int taskId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COLUMN_ID + "=?";
        String[] whereArgs = {String.valueOf(taskId)};
        db.delete(TABLE_TASKS, whereClause, whereArgs);
        db.close();
    }
    // Add this method in your TaskDatabaseHelper class
    public void updateCompletionStatus(int taskId, int completed) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COMPLETED, completed);
        db.update(TABLE_TASKS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(taskId)});
        db.close();
    }

    public Task getTaskById(int taskId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID, COLUMN_TITLE, COLUMN_DESCRIPTION, COLUMN_PRIORITY, COLUMN_DUE_DATE, COLUMN_COMPLETED};
        String selection = COLUMN_ID + "=?";
        String[] selectionArgs = {String.valueOf(taskId)};

        Cursor cursor = db.query(TABLE_TASKS, columns, selection, selectionArgs, null, null, null);

        Task task = null;
        if (cursor.moveToFirst()) {
            String title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE));
            String description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION));
            int priority = Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_PRIORITY)));
            String dueDate = cursor.getString(cursor.getColumnIndex(COLUMN_DUE_DATE));
            int completionStatus = Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_COMPLETED)));

            task = new Task(String.valueOf(taskId), title, description, priority, dueDate, completionStatus);
        }

        cursor.close();
        db.close();
        return task;
    }

    // Method to update a note in the database.
    public boolean updateTask(int noteId, String updatedTitle, String updatedDescription) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, updatedTitle);
        values.put(COLUMN_DESCRIPTION, updatedDescription);
        String whereClause = COLUMN_ID + "=?";
        String[] whereArgs = {String.valueOf(noteId)};
        int rowsAffected = db.update(TABLE_TASKS, values, whereClause, whereArgs);
        db.close();
        return rowsAffected > 0;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Add any necessary changes for version 2 here
            db.execSQL("ALTER TABLE " + TABLE_TASKS + " ADD COLUMN " + COLUMN_PRIORITY + " INTEGER DEFAULT 0;");
            db.execSQL("ALTER TABLE " + TABLE_TASKS + " ADD COLUMN " + COLUMN_DUE_DATE + " TEXT;");
            db.execSQL("ALTER TABLE " + TABLE_TASKS + " ADD COLUMN " + COLUMN_COMPLETED + " INTEGER DEFAULT 0;");
        }
        // Add more upgrade logic for future versions as needed
    }

}

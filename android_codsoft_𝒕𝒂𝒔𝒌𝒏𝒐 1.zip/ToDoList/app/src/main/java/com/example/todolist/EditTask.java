package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class EditTask extends AppCompatActivity {
    private TaskDatabaseHelper taskDatabaseHelper;
    private int taskId;
    private EditText titleEditText, descriptionEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task);

        taskDatabaseHelper = new TaskDatabaseHelper(EditTask.this);
        titleEditText = findViewById(R.id.title);
        descriptionEditText = findViewById(R.id.desc);

        // Get the task ID from the intent extra.
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            taskId = extras.getInt("task_id", -1);
        }

        // Verify that you have received the correct taskId.
        Log.d("EditTask", "Received taskId: " + taskId);

        // Fetch the task details from the database based on the note ID.
        Task task = taskDatabaseHelper.getTaskById(taskId);

        if (task != null) {
            // Set the title and description in the EditText fields.
            titleEditText.setText(task.getTitle());
            descriptionEditText.setText(task.getDescription());
        } else {
            // Handle the case where the task with the given ID is not found.
            Log.e("EditTask", "Task with ID " + taskId + " not found in the database.");
            // You might want to show an error message or take appropriate action here.
        }



        FloatingActionButton update = findViewById(R.id.updateTask);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the updated title and description from EditText fields.
                String updatedTitle = titleEditText.getText().toString();
                String updatedDescription = descriptionEditText.getText().toString();

                // Update the note in the database.
                boolean isUpdated = taskDatabaseHelper.updateTask(taskId, updatedTitle, updatedDescription);

                if (isUpdated) {
                    Toast.makeText(EditTask.this, "Task updated successfully.", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(EditTask.this, MainActivity.class);
                    startActivity(i);
                    finish(); // Finish the activity and go back to the MainActivity.
                } else {
                    Toast.makeText(EditTask.this, "Failed to update Task.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
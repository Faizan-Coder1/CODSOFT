package com.example.todolist;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {

    private List<Task> taskList;
    private Context context;
    TaskDatabaseHelper taskDatabaseHelper;
    public TaskAdapter(List<Task> taskList, Context context) {
        this.taskList = taskList;
        this.context = context;
        taskDatabaseHelper = new TaskDatabaseHelper(context); // Initialize here
    }

    public void setTaskList(List<Task> noteList) {
        this.taskList = noteList;
        notifyDataSetChanged();
    }

    public void sortTasksByDueDateAndStatus() {
        taskList.sort(new Comparator<Task>() {
            @Override
            public int compare(Task task1, Task task2) {
                // Compare by due date
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                try {
                    if (task1.getDueDate() != null && task2.getDueDate() != null) {
                        Date date1 = sdf.parse(task1.getDueDate());
                        Date date2 = sdf.parse(task2.getDueDate());
                        int dateComparison = date1.compareTo(date2);
                        if (dateComparison != 0) {
                            return dateComparison;
                        }
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }


                // If due dates are equal, compare by completion status
                return Integer.compare(task1.getCompleted(), task2.getCompleted());
            }
        });
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.titleTextView.setText(task.getTitle());
        holder.descriptionTextView.setText(task.getDescription());

        // Display priority
        holder.priorityTextView.setText("Priority: " + task.getPriority());

        // Display due date
        holder.dueDateTextView.setText("Due Date: " + task.getDueDate());

        // Display completion status and handle checkbox
        holder.completedCheckBox.setChecked(task.getCompleted() == 1);
        // ...
        holder.completedCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            int newCompletedStatus = isChecked ? 1 : 0;
            taskDatabaseHelper.updateCompletionStatus(Integer.parseInt(String.valueOf(task.getId())), newCompletedStatus);
        });

        holder.itemView.setOnClickListener(view -> showUpdateOrDeleteDialog(task));
    }

    private void showUpdateOrDeleteDialog(Task task) {
        int id = Integer.valueOf(task.getId());
        // Example:
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Choose an option")
                .setMessage("Do you want to update or delete the task?")
                .setPositiveButton("Edit", (dialog, which) -> {
                    Intent intent = new Intent(context, EditTask.class);
                    intent.putExtra("task_id", id);
                    context.startActivity(intent);
                })
                .setNegativeButton("Delete", (dialog, which) -> {
                    TaskDatabaseHelper taskDatabaseHelper = new TaskDatabaseHelper(context);
                    taskDatabaseHelper.deleteTask(id); // Delete the note using the DBHandler method
                    taskList.remove(task);
                    notifyDataSetChanged();
                    Toast.makeText(context, "Note deleted.", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("Cancel", null)
                .show();
    }


    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView descriptionTextView;
        TextView priorityTextView;
        TextView dueDateTextView;
        CheckBox completedCheckBox;

        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
            priorityTextView = itemView.findViewById(R.id.priorityTextView);
            dueDateTextView = itemView.findViewById(R.id.dueDateTextView);
            completedCheckBox = itemView.findViewById(R.id.completedCheckBox);
        }
    }



}
